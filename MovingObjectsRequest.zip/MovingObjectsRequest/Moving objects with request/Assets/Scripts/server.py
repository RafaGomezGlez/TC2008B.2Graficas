from http.server import HTTPServer, BaseHTTPRequestHandler
import random


class MyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        cordX1=random.randint(-10,10)
        #cordY1=random.randint(0,10)
        cordZ1=random.randint(-7,7)
        cordX2=random.randint(-10,10)
        #cordY2=random.randint(0,10)
        cordZ2=random.randint(-7,7)
        cordX3=random.randint(-10,10)
        #cordY3=random.randint(0,10)
        cordZ3=random.randint(-7,7)
        cordX4=random.randint(-10,10)
        #cordY4=random.randint(0,10)
        cordZ4=random.randint(-7,7)
        cordX5=random.randint(-10,10)
        #cordY5=random.randint(0,10)
        cordZ5=random.randint(-7,7)
        response = """{
            \"data\": [
                {\"x\":%s, \"y\":0, \"z\":%s},
                {\"x\":%s, \"y\":0, \"z\":%s},
                {\"x\":%s, \"y\":0, \"z\":%s},
                {\"x\":%s, \"y\":0, \"z\":%s},
                {\"x\":%s, \"y\":0, \"z\":%s}
            ]
        }"""%(cordX1,cordZ1,cordX2,cordZ2,cordX3, cordZ3,cordX4, cordZ4,cordX5, cordZ5,)
        # send 200 response
        self.send_response(200)
        # send response headers
        self.end_headers()
        # send the body of the response
        self.wfile.write(bytes(response, "utf-8"))

httpd = HTTPServer(('localhost', 8000), MyHandler)
httpd.serve_forever()